const root = document.getElementById("root");
root.innerHTML = "<h1>App funcional: Control de empleados</h1><p>Prototipo simple funcionando</p>";